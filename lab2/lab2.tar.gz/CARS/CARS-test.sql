/*
Victor Wei - vywei@calpoly.edu
Eddie Kesicki - ekesicki@calpoly.edu
*/

SELECT COUNT(*) AS CarNames FROM CarNames;
SELECT COUNT(*) AS CarMakers FROM CarMakers;
SELECT COUNT(*) AS CarsData FROM CarsData;
SELECT COUNT(*) AS Continents FROM Continents;
SELECT COUNT(*) AS Countries FROM Countries;
SELECT COUNT(*) AS ModelList FROM ModelList;