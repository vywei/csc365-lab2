/*
Victor Wei - vywei@calpoly.edu
Eddie Kesicki - ekesicki@calpoly.edu
*/

INSERT INTO Continents (ContId, Continent) 
    VALUES (1, 'america');
INSERT INTO Continents (ContId, Continent) 
    VALUES (2, 'europe');
INSERT INTO Continents (ContId, Continent) 
    VALUES (3, 'asia');
INSERT INTO Continents (ContId, Continent) 
    VALUES (4, 'africa');
INSERT INTO Continents (ContId, Continent) 
    VALUES (5, 'australia');
