/*
Victor Wei - vywei@calpoly.edu
Eddie Kesicki - ekesicki@calpoly.edu
*/

INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (1, 1, 'amc');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (2, 2, 'audi');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (3, 3, 'bmw');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (4, 4, 'buick');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (5, 4, 'cadillac');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (6, 5, 'capri');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (7, 4, 'chevrolet');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (8, 6, 'chrysler');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (9, 7, 'citroen');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (10, 8, 'datsun');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (11, 6, 'dodge');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (12, 9, 'fiat');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (13, 5, 'ford');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (14, 10, 'hi');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (15, 11, 'honda');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (16, 12, 'mazda');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (17, 13, 'mercedes');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (18, 13, 'mercedes-benz');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (19, 5, 'mercury');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (20, 8, 'nissan');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (21, 4, 'oldsmobile');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (22, 14, 'opel');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (23, 15, 'peugeot');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (24, 6, 'plymouth');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (25, 4, 'pontiac');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (26, 16, 'renault');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (27, 17, 'saab');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (28, 18, 'subaru');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (29, 19, 'toyota');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (30, 20, 'triumph');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (31, 2, 'volkswagen');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (32, 21, 'volvo');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (33, 22, 'kia');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (34, 23, 'hyundai');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (35, 6, 'jeep');
INSERT INTO ModelList (ModelId, Maker, Model) 
    VALUES (36, 19, 'scion');
