/*
Victor Wei - vywei@calpoly.edu
Eddie Kesicki - ekesicki@calpoly.edu
*/

DROP TABLE CarNames;
DROP TABLE CarMakers;
DROP TABLE CarData;
DROP TABLE Continents;
DROP TABLE Countries;
DROP TABLE ModelList;