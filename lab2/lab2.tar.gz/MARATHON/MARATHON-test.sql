/*
Victor Wei - vywei@calpoly.edu
Eddie Kesicki - ekesicki@calpoly.edu
*/

SELECT COUNT(*) AS Marathon from Marathon;