/*
Victor Wei - vywei@calpoly.edu
Eddie Kesicki - ekesicki@calpoly.edu
*/

INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1990, 1, 701);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1991, 1, 681);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1992, 1, 791);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1993, 1, 801);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1994, 1, 849);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1995, 1, 818);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1996, 1, 804);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1997, 1, 928);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1998, 1, 816);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1999, 1, 959);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2000, 1, 955);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2001, 1, 1086);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2002, 1, 1151);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2003, 1, 1193);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2004, 1, 1243);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2002, 2, 2);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2003, 2, 142);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2004, 2, 346);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1990, 3, 2880);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1991, 3, 3036);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1992, 3, 3026);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1993, 3, 3008);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1994, 3, 2852);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1995, 3, 2678);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1996, 3, 2636);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1997, 3, 2453);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1998, 3, 2677);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1999, 3, 2401);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2000, 3, 2696);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2001, 3, 2943);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2002, 3, 3045);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2003, 3, 3128);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2004, 3, 2724);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1990, 4, 1128);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1991, 4, 1218);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1992, 4, 1471);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1993, 4, 1598);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1994, 4, 1744);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1995, 4, 1693);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1996, 4, 1728);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1997, 4, 1735);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1998, 4, 1806);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1999, 4, 1651);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2000, 4, 1703);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2001, 4, 1746);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2002, 4, 1775);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2003, 4, 1849);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2004, 4, 1716);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1990, 5, 2025);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1991, 5, 1960);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1992, 5, 1976);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1993, 5, 2193);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1994, 5, 2347);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1995, 5, 2257);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1996, 5, 2243);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1997, 5, 2245);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1998, 5, 2201);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1999, 5, 2277);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2000, 5, 2257);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2001, 5, 2450);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2002, 5, 2437);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2003, 5, 2396);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2004, 5, 2419);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1990, 6, 2976);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1991, 6, 3083);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1992, 6, 3137);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1993, 6, 3090);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1994, 6, 2985);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1995, 6, 3042);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1996, 6, 2992);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1997, 6, 2902);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1998, 6, 2725);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1999, 6, 2833);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2000, 6, 2858);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2001, 6, 2909);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2002, 6, 2735);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2003, 6, 2922);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2004, 6, 3069);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1990, 7, 3990);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1991, 7, 4188);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1992, 7, 4289);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1993, 7, 4193);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1994, 7, 3963);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1995, 7, 3936);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1996, 7, 4027);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1997, 7, 4312);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1998, 7, 4121);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1999, 7, 4522);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2000, 7, 4517);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2001, 7, 5239);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2002, 7, 5058);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2003, 7, 5636);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2004, 7, 5761);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1990, 8, 961);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1991, 8, 1140);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1992, 8, 1176);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1993, 8, 1347);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1994, 8, 1311);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1995, 8, 1321);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1996, 8, 1389);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1997, 8, 1386);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1998, 8, 1380);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1999, 8, 1374);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2000, 8, 1398);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2001, 8, 1456);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2002, 8, 1355);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2003, 8, 1376);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2004, 8, 1396);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1990, 9, 4273);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1991, 9, 4674);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1992, 9, 4607);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1993, 9, 4593);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1994, 9, 4232);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1995, 9, 4228);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1996, 9, 3980);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1997, 9, 3874);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1998, 9, 4078);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1999, 9, 4158);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2000, 9, 4352);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2001, 9, 4859);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2002, 9, 5055);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2003, 9, 5194);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2004, 9, 5790);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1990, 10, 1670);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1991, 10, 1985);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1992, 10, 2718);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1993, 10, 2272);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1994, 10, 2391);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1995, 10, 2483);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1996, 10, 2373);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1997, 10, 2368);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1998, 10, 2408);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1999, 10, 2500);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2000, 10, 2489);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2001, 10, 2871);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2002, 10, 2764);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2003, 10, 2638);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2004, 10, 2220);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1996, 11, 74);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1997, 11, 68);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1998, 11, 53);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1999, 11, 69);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2000, 11, 88);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2001, 11, 91);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2002, 11, 104);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2003, 11, 118);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2004, 11, 114);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1996, 12, 68);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1997, 12, 147);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1998, 12, 229);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1999, 12, 232);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2000, 12, 366);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2001, 12, 366);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2002, 12, 433);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2003, 12, 490);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2004, 12, 598);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1990, 13, 4024);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1991, 13, 4095);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1992, 13, 4216);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1993, 13, 4219);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1994, 13, 3961);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1995, 13, 3802);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1996, 13, 3561);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1997, 13, 3783);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1998, 13, 3936);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1999, 13, 3921);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2000, 13, 4387);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2001, 13, 4824);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2002, 13, 5073);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2003, 13, 4944);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2004, 13, 5488);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1990, 14, 2861);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1991, 14, 2860);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1992, 14, 2719);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1993, 14, 2650);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1994, 14, 2685);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1995, 14, 2578);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1996, 14, 2529);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1997, 14, 2767);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1998, 14, 2402);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1999, 14, 2585);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2000, 14, 2763);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2001, 14, 2808);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2002, 14, 2935);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2003, 14, 3200);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2004, 14, 3207);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1990, 15, 3691);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1991, 15, 4178);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1992, 15, 4291);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1993, 15, 4327);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1994, 15, 4030);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1995, 15, 3537);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1996, 15, 3599);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1997, 15, 3734);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1998, 15, 3894);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1999, 15, 3721);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2000, 15, 4087);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2001, 15, 4230);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2002, 15, 4223);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2003, 15, 4557);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2004, 15, 4659);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1990, 16, 1354);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1991, 16, 1481);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1992, 16, 1712);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1993, 16, 1926);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1994, 16, 1923);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1995, 16, 2007);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1996, 16, 1892);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1997, 16, 1955);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1998, 16, 2079);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1999, 16, 2176);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2000, 16, 2097);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2001, 16, 2276);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2002, 16, 2331);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2003, 16, 2531);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2004, 16, 2684);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1990, 17, 5642);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1991, 17, 5532);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1992, 17, 5392);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1993, 17, 5034);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1994, 17, 4752);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1995, 17, 4644);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1996, 17, 4673);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1997, 17, 4783);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1998, 17, 4928);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1999, 17, 5201);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2000, 17, 5083);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2001, 17, 5390);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2002, 17, 5816);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2003, 17, 6181);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2004, 17, 6325);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1990, 18, 3871);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1991, 18, 4170);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1992, 18, 3879);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1993, 18, 3692);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1994, 18, 3659);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1995, 18, 3917);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1996, 18, 3721);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1997, 18, 3799);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1998, 18, 4240);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1999, 18, 3987);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2000, 18, 4098);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2001, 18, 4469);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2002, 18, 4529);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2003, 18, 4574);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2004, 18, 4865);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1990, 19, 3677);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1991, 19, 4012);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1992, 19, 4364);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1993, 19, 4271);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1994, 19, 3975);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1995, 19, 3816);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1996, 19, 4090);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1997, 19, 4021);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1998, 19, 4099);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1999, 19, 3956);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2000, 19, 3951);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2001, 19, 4072);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2002, 19, 3867);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2003, 19, 3854);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2004, 19, 4259);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1990, 20, 2700);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1991, 20, 3401);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1992, 20, 3319);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1993, 20, 3411);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1994, 20, 3080);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1995, 20, 3056);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1996, 20, 2824);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1997, 20, 3146);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1998, 20, 3339);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1999, 20, 3545);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2000, 20, 2840);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2001, 20, 3509);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2002, 20, 3169);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2003, 20, 4677);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2004, 20, 3374);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1991, 21, 81);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1992, 21, 260);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1993, 21, 417);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1994, 21, 552);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1995, 21, 557);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1996, 21, 606);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1997, 21, 644);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1998, 21, 776);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1999, 21, 878);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2000, 21, 1333);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2001, 21, 1087);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2002, 21, 1201);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2003, 21, 1342);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2004, 21, 1459);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1990, 22, 1113);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1991, 22, 1213);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1992, 22, 1396);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1993, 22, 1327);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1994, 22, 1249);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1995, 22, 1318);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1996, 22, 1360);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1997, 22, 1400);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1998, 22, 1446);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1999, 22, 1447);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2000, 22, 1398);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2001, 22, 1541);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2002, 22, 1372);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2003, 22, 1431);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2004, 22, 1598);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1990, 23, 815);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1991, 23, 909);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1992, 23, 926);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1993, 23, 989);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1994, 23, 967);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1995, 23, 1042);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1996, 23, 1044);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1997, 23, 1046);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1998, 23, 1181);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (1999, 23, 1210);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2000, 23, 1267);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2001, 23, 1241);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2002, 23, 1282);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2003, 23, 1368);
INSERT INTO degrees (Year, Campus, Degrees) 
    VALUES (2004, 23, 1454);
