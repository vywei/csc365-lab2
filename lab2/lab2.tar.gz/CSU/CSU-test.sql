/*
Victor Wei - vywei@calpoly.edu
Eddie Kesicki - ekesicki@calpoly.edu
*/

SELECT COUNT(*) AS Campuses FROM campuses;
SELECT COUNT(*) AS CSUFees FROM csuFees;
SELECT COUNT(*) AS Degrees FROM degrees;
SELECT COUNT(*) AS DisciplineEnrollments FROM disciplineEnrollments;
SELECT COUNT(*) AS Disciplines FROM disciplines;
SELECT COUNT(*) AS Enrollments FROM enrollments;
SELECT COUNT(*) AS Faculty FROM faculty;
