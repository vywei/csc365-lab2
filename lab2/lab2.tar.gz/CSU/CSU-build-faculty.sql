/*
Victor Wei - vywei@calpoly.edu
Eddie Kesicki - ekesicki@calpoly.edu
*/

INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (1, 2002, 357.1);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (2, 2002, 48.4);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (3, 2002, 742.8);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (4, 2002, 449.8);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (5, 2002, 552.0);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (6, 2002, 694.6);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (7, 2002, 1257.3);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (8, 2002, 435.4);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (9, 2002, 1429.0);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (10, 2002, 831.5);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (11, 2002, 53.8);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (12, 2002, 156.4);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (13, 2002, 1141.2);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (14, 2002, 873.5);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (15, 2002, 1102.0);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (16, 2002, 670.9);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (17, 2002, 1555.7);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (18, 2002, 1173.3);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (19, 2002, 1177.5);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (20, 2002, 945.6);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (21, 2002, 290.4);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (22, 2002, 334.4);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (23, 2002, 319.5);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (1, 2003, 361.6);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (2, 2003, 92.5);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (3, 2003, 697.4);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (4, 2003, 470.5);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (5, 2003, 526.0);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (6, 2003, 738.0);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (7, 2003, 1253.5);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (8, 2003, 406.2);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (9, 2003, 1388.5);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (10, 2003, 793.7);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (11, 2003, 53.6);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (12, 2003, 153.9);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (13, 2003, 1163.1);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (14, 2003, 857.5);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (15, 2003, 1107.2);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (16, 2003, 660.0);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (17, 2003, 1447.1);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (18, 2003, 1116.3);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (19, 2003, 1091.3);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (20, 2003, 935.7);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (21, 2003, 282.1);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (22, 2003, 315.4);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (23, 2003, 333.9);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (1, 2004, 346.2);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (2, 2004, 117.7);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (3, 2004, 656.0);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (4, 2004, 406.2);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (5, 2004, 548.3);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (6, 2004, 809.1);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (7, 2004, 1111.6);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (8, 2004, 377.9);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (9, 2004, 1328.9);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (10, 2004, 798.5);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (11, 2004, 78.1);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (12, 2004, 151.4);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (13, 2004, 1112.1);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (14, 2004, 736.8);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (15, 2004, 1027.6);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (16, 2004, 597.0);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (17, 2004, 1363.5);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (18, 2004, 1083.3);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (19, 2004, 1045.3);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (20, 2004, 886.5);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (21, 2004, 257.4);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (22, 2004, 288.1);
INSERT INTO faculty (Campus, Year, Faculty) 
    VALUES (23, 2004, 307.0);
