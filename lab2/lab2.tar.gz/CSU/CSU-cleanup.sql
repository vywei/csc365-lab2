/*
Victor Wei - vywei@calpoly.edu
Eddie Kesicki - ekesicki@calpoly.edu
*/

DROP TABLE csuFees;
DROP TABLE degrees;
DROP TABLE disciplineEnrollments;
DROP TABLE disciplines;
DROP TABLE enrollments;
DROP TABLE faculty;
DROP TABLE campuses;