/* Edward Kesicki
   ekesicki@calpoly.edu

   Victor Wei
   vywei@calpoly.edu
*/

SOURCE STUDENTS-build-list.sql;
SOURCE STUDENTS-build-teachers.sql; 
