/*
Victor Wei - vywei@calpoly.edu
Eddie Kesicki - ekesicki@calpoly.edu
*/

INSERT INTO Countries (CountryId, CountryName, Continent) 
    VALUES (1, 'usa', 1);
INSERT INTO Countries (CountryId, CountryName, Continent) 
    VALUES (2, 'germany', 2);
INSERT INTO Countries (CountryId, CountryName, Continent) 
    VALUES (3, 'france', 2);
INSERT INTO Countries (CountryId, CountryName, Continent) 
    VALUES (4, 'japan', 3);
INSERT INTO Countries (CountryId, CountryName, Continent) 
    VALUES (5, 'italy', 2);
INSERT INTO Countries (CountryId, CountryName, Continent) 
    VALUES (6, 'sweden', 2);
INSERT INTO Countries (CountryId, CountryName, Continent) 
    VALUES (7, 'uk', 2);
INSERT INTO Countries (CountryId, CountryName, Continent) 
    VALUES (8, 'korea', 3);
INSERT INTO Countries (CountryId, CountryName, Continent) 
    VALUES (9, 'russia', 2);
INSERT INTO Countries (CountryId, CountryName, Continent) 
    VALUES (10, 'nigeria', 4);
INSERT INTO Countries (CountryId, CountryName, Continent) 
    VALUES (11, 'australia', 5);
INSERT INTO Countries (CountryId, CountryName, Continent) 
    VALUES (12, 'new zealand', 5);
INSERT INTO Countries (CountryId, CountryName, Continent) 
    VALUES (13, 'egypt', 4);
INSERT INTO Countries (CountryId, CountryName, Continent) 
    VALUES (14, 'mexico', 1);
INSERT INTO Countries (CountryId, CountryName, Continent) 
    VALUES (15, 'brazil', 1);
