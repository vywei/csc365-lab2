/*
Victor Wei - vywei@calpoly.edu
Eddie Kesicki - ekesicki@calpoly.edu
*/

INSERT INTO CarMakers (Id, Maker, FullName, Country) 
    VALUES (1, 'amc', 'American Motor Company', 1);
INSERT INTO CarMakers (Id, Maker, FullName, Country) 
    VALUES (2, 'volkswagen', 'Volkswagen', 2);
INSERT INTO CarMakers (Id, Maker, FullName, Country) 
    VALUES (3, 'bmw', 'BMW', 2);
INSERT INTO CarMakers (Id, Maker, FullName, Country) 
    VALUES (4, 'gm', 'General Motors', 1);
INSERT INTO CarMakers (Id, Maker, FullName, Country) 
    VALUES (5, 'ford', 'Ford Motor Company', 1);
INSERT INTO CarMakers (Id, Maker, FullName, Country) 
    VALUES (6, 'chrysler', 'Chrysler', 1);
INSERT INTO CarMakers (Id, Maker, FullName, Country) 
    VALUES (7, 'citroen', 'Citroen', 3);
INSERT INTO CarMakers (Id, Maker, FullName, Country) 
    VALUES (8, 'nissan', 'Nissan Motors', 4);
INSERT INTO CarMakers (Id, Maker, FullName, Country) 
    VALUES (9, 'fiat', 'Fiat', 5);
INSERT INTO CarMakers (Id, Maker, FullName, Country) 
    VALUES (10, 'hi', 'hi', null);
INSERT INTO CarMakers (Id, Maker, FullName, Country) 
    VALUES (11, 'honda', 'Honda', 4);
INSERT INTO CarMakers (Id, Maker, FullName, Country) 
    VALUES (12, 'mazda', 'Mazda', 4);
INSERT INTO CarMakers (Id, Maker, FullName, Country) 
    VALUES (13, 'daimler benz', 'Daimler Benz', 2);
INSERT INTO CarMakers (Id, Maker, FullName, Country) 
    VALUES (14, 'opel', 'Opel', 2);
INSERT INTO CarMakers (Id, Maker, FullName, Country) 
    VALUES (15, 'peugeaut', 'Peugeaut', 3);
INSERT INTO CarMakers (Id, Maker, FullName, Country) 
    VALUES (16, 'renault', 'Renault', 3);
INSERT INTO CarMakers (Id, Maker, FullName, Country) 
    VALUES (17, 'saab', 'Saab', 6);
INSERT INTO CarMakers (Id, Maker, FullName, Country) 
    VALUES (18, 'subaru', 'Subaru', 4);
INSERT INTO CarMakers (Id, Maker, FullName, Country) 
    VALUES (19, 'toyota', 'Toyota', 4);
INSERT INTO CarMakers (Id, Maker, FullName, Country) 
    VALUES (20, 'triumph', 'Triumph', 7);
INSERT INTO CarMakers (Id, Maker, FullName, Country) 
    VALUES (21, 'volvo', 'Volvo', 6);
INSERT INTO CarMakers (Id, Maker, FullName, Country) 
    VALUES (22, 'kia', 'Kia Motors', 8);
INSERT INTO CarMakers (Id, Maker, FullName, Country) 
    VALUES (23, 'hyundai', 'Hyundai', 8);
